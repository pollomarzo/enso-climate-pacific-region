## Supplementary Figure Legends

**Figure S1.** The red spots on the figure indicate locations where Air temperature and SST correlations have different signs.

**Figure S2.** This figure illustrates the disparity between the correlation coefficients (r values) of air temperature with ONI and SST with ONI, irrespective of their signs.